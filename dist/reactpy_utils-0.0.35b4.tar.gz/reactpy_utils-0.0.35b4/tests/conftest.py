from __future__ import annotations

import asyncio
import os
import subprocess
from typing import AsyncGenerator

import pytest
from _pytest.config import Config
from _pytest.config.argparsing import Parser
from playwright.async_api import Browser, Page

from reactpy.config import (
    REACTPY_ASYNC_RENDERING,
    REACTPY_DEBUG,
    REACTPY_TESTS_DEFAULT_TIMEOUT,
)
from reactpy.testing import (
    BackendFixture,
    DisplayFixture,
    capture_reactpy_logs,
    clear_reactpy_web_modules_dir,
)
from reactpy.testing.common import GITHUB_ACTIONS


REACTPY_ASYNC_RENDERING.set_current(True)
REACTPY_DEBUG.set_current(True)


def pytest_addoption(parser: Parser) -> None:
    parser.addoption(
        "--headless",
        dest="headless",
        action="store_true",
        help="Don't open a browser window when running web-based tests",
    )


@pytest.fixture(autouse=True, scope="session")
def install_playwright():
    subprocess.run(["playwright", "install", "chromium"], check=True)  # noqa: S607, S603
    subprocess.run(["playwright", "install-deps"], check=True)  # noqa: S607, S603


@pytest.fixture(autouse=True, scope="session")
def rebuild():
    # When running inside `hatch test`, the `HATCH_ENV_ACTIVE` environment variable
    # is set. If we try to run `hatch build` with this variable set, Hatch will
    # complain that the current environment is not a builder environment.
    # To fix this, we remove `HATCH_ENV_ACTIVE` from the environment variables
    # passed to the subprocess.
    env = os.environ.copy()
    env.pop("HATCH_ENV_ACTIVE", None)
    subprocess.run(["hatch", "build", "-t", "wheel"], check=True, env=env)  # noqa: S607, S603


@pytest.fixture(autouse=True, scope="function")
def create_hook_state():
    """This fixture is a bug fix related to `pytest_asyncio`.

    Usually the hook stack is created automatically within the display fixture, but context
    variables aren't retained within `pytest_asyncio` async fixtures. As a workaround,
    this fixture ensures that the hook stack is created before each test is run.

    Ref: https://github.com/pytest-dev/pytest-asyncio/issues/127
    """
    from reactpy.core._life_cycle_hook import HOOK_STACK

    token = HOOK_STACK.initialize()
    yield token
    HOOK_STACK.reset(token)


@pytest.fixture
async def display(server: BackendFixture, page: Page) -> AsyncGenerator[DisplayFixture, None]:
    async with DisplayFixture(server, page) as display:
        yield display


@pytest.fixture
async def server():
    async with BackendFixture() as server:
        yield server


@pytest.fixture
async def pico_container(display: DisplayFixture):
    return PicoContainer(display)


@pytest.fixture
async def page(browser: Browser) -> AsyncGenerator[Page, None]:
    context = await browser.new_context(permissions=["clipboard-read", "clipboard-write"])
    pg = await context.new_page()
    pg.set_default_timeout(REACTPY_TESTS_DEFAULT_TIMEOUT.current * 1000)
    try:
        yield pg
    finally:
        await pg.close()
        await context.close()


@pytest.fixture
async def browser(pytestconfig: Config):
    from playwright.async_api import async_playwright

    async with async_playwright() as pw:
        yield await pw.chromium.launch(
            headless=bool(pytestconfig.option.headless) or GITHUB_ACTIONS
        )


@pytest.fixture(scope="session")
def event_loop_policy():
    if os.name == "nt":  # nocov
        return asyncio.WindowsProactorEventLoopPolicy()
    else:
        return asyncio.DefaultEventLoopPolicy()


@pytest.fixture(autouse=True, scope="session")
def clear_web_modules_dir_after_session():
    """Clear web modules after the test session to clean up."""
    yield
    # Only clear after all tests complete
    clear_reactpy_web_modules_dir()


@pytest.fixture(autouse=True)
def assert_no_logged_exceptions():
    with capture_reactpy_logs() as records:
        yield
        try:
            for r in records:
                if r.exc_info is not None and r.exc_info[1] is not None:
                    raise r.exc_info[1]
        finally:
            records.clear()
